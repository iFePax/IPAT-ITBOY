lineaCarrilBlancaLBB = lineaCarrilBlanca LINEA DE BORDE BLANCA
lineaCarrilBlancaLBA = lineaCarrilBlanca LINEA DE BORDE BLANCA
lineaCarrilBlancaLA = lineaCarrilBlanca LINEA ANTIBLOQUEO


id_CTsemaforo = controles de trancito inciso B semaforo
id_RCC = Responsabilidad civil contractual
id_RE = Responsabilidad Extracontractual

id_DQCA= Datos de quien conoce del accidente

cvp_id_cvp = conductoresvehiculospropietarios_id_conductoresvehiculospropietarios 

cvpanexo1_id_cvp = conductoresvehiculospropietariosanexo1_id_conductoresvehiculospropietarios