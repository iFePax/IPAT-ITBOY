-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-06-2022 a las 03:17:00
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `itboy`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agentetransito`
--

CREATE TABLE `agentetransito` (
  `id_agentetransito` int(11) NOT NULL,
  `agentetransito` tinyint(1) DEFAULT NULL,
  `controlestransito_id_controlestransito` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `anexo1`
--

CREATE TABLE `anexo1` (
  `id_anexo1` int(11) NOT NULL,
  `pertenecienteinformeaccidente` varchar(10) DEFAULT NULL,
  `itboy_itboy_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `anexo2`
--

CREATE TABLE `anexo2` (
  `id_anexo2` int(11) NOT NULL,
  `informeaccidente` int(11) DEFAULT NULL,
  `itboy_itboy_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area`
--

CREATE TABLE `area` (
  `id_area` int(11) NOT NULL,
  `rural` tinyint(1) DEFAULT NULL,
  `nacional` tinyint(1) DEFAULT NULL,
  `departamental` tinyint(1) DEFAULT NULL,
  `municipal` tinyint(1) DEFAULT NULL,
  `urbana` tinyint(1) DEFAULT NULL,
  `caracteristicaslugar_id_caraclugar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calzadas`
--

CREATE TABLE `calzadas` (
  `id_calzada` int(11) NOT NULL,
  `una` tinyint(1) DEFAULT NULL,
  `dos` tinyint(1) DEFAULT NULL,
  `tresmas` tinyint(1) DEFAULT NULL,
  `variable` tinyint(1) DEFAULT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caracteristicaslugar`
--

CREATE TABLE `caracteristicaslugar` (
  `id_caraclugar` int(11) NOT NULL,
  `informepolicial_id_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caracteristicasvia`
--

CREATE TABLE `caracteristicasvia` (
  `id_caracvia` int(11) NOT NULL,
  `informepolicial_id_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carga`
--

CREATE TABLE `carga` (
  `id_carga` int(11) NOT NULL,
  `extradimencional` tinyint(1) DEFAULT NULL,
  `extrapesada` tinyint(1) DEFAULT NULL,
  `mercanciapeligrosa` tinyint(1) DEFAULT NULL,
  `clasemercancia` varchar(255) DEFAULT NULL,
  `modalidadtrans_id_modtrans` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carriles`
--

CREATE TABLE `carriles` (
  `id_carriles` int(11) NOT NULL,
  `un` tinyint(1) DEFAULT NULL,
  `dos` tinyint(1) DEFAULT NULL,
  `tresmas` tinyint(1) DEFAULT NULL,
  `variable` tinyint(1) DEFAULT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `choqueobjeto`
--

CREATE TABLE `choqueobjeto` (
  `id_choqueobjeto` int(11) NOT NULL,
  `vehiculo` tinyint(1) DEFAULT NULL,
  `tren` tinyint(1) DEFAULT NULL,
  `semoviente` tinyint(1) DEFAULT NULL,
  `claseaccidente_id_claseaccidente` int(11) NOT NULL,
  `claseaccidente_id_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `choqueobjetofijo`
--

CREATE TABLE `choqueobjetofijo` (
  `id_choqueobjeto` int(11) NOT NULL,
  `muro` tinyint(1) DEFAULT NULL,
  `poste` tinyint(1) DEFAULT NULL,
  `arbol` tinyint(1) DEFAULT NULL,
  `baranda` tinyint(1) DEFAULT NULL,
  `semaforo` tinyint(1) DEFAULT NULL,
  `inmueble` tinyint(1) DEFAULT NULL,
  `hidrante` tinyint(1) DEFAULT NULL,
  `vallasenal` tinyint(1) DEFAULT NULL,
  `tarimacaseta` tinyint(1) DEFAULT NULL,
  `vehciuloestacionado` tinyint(1) DEFAULT NULL,
  `otro` varchar(255) DEFAULT NULL,
  `claseaccidente_id_claseaccidente` int(11) NOT NULL,
  `claseaccidente_id_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `claseaccidente`
--

CREATE TABLE `claseaccidente` (
  `id_claseaccidente` int(11) NOT NULL,
  `choque` tinyint(1) DEFAULT NULL,
  `atropello` tinyint(1) DEFAULT NULL,
  `volcamiento` tinyint(1) DEFAULT NULL,
  `caidaocupante` tinyint(1) DEFAULT NULL,
  `incendio` tinyint(1) DEFAULT NULL,
  `otro` varchar(255) DEFAULT NULL,
  `informepolicial_id_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `claseservicio`
--

CREATE TABLE `claseservicio` (
  `id_claseservicio` int(11) NOT NULL,
  `oficial` tinyint(1) DEFAULT NULL,
  `publico` tinyint(1) DEFAULT NULL,
  `particular` tinyint(1) DEFAULT NULL,
  `diplomatico` tinyint(1) DEFAULT NULL,
  `vehiculopropietario_id_propietarioclasevehiculo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `condicion`
--

CREATE TABLE `condicion` (
  `id_detallescondicion` int(11) NOT NULL,
  `peaton` tinyint(1) DEFAULT NULL,
  `pasajero` tinyint(1) DEFAULT NULL,
  `acompanante` tinyint(1) DEFAULT NULL,
  `detallesvictima_id_victimadetalles` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `condicionclimatica`
--

CREATE TABLE `condicionclimatica` (
  `id_condicionesclima` int(11) NOT NULL,
  `granizo` tinyint(1) DEFAULT NULL,
  `lluvia` tinyint(1) DEFAULT NULL,
  `niebla` tinyint(1) DEFAULT NULL,
  `viento` tinyint(1) DEFAULT NULL,
  `normal` tinyint(1) DEFAULT NULL,
  `caracteristicaslugar_id_caraclugar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `condiciones`
--

CREATE TABLE `condiciones` (
  `id_condiciones` int(11) NOT NULL,
  `aceite` tinyint(1) DEFAULT NULL,
  `humeda` tinyint(1) DEFAULT NULL,
  `lodo` tinyint(1) DEFAULT NULL,
  `alcantarilladestapada` tinyint(1) DEFAULT NULL,
  `materialorganico` tinyint(1) DEFAULT NULL,
  `materialsuelto` tinyint(1) DEFAULT NULL,
  `seca` tinyint(1) DEFAULT NULL,
  `otra` varchar(255) DEFAULT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conductor`
--

CREATE TABLE `conductor` (
  `id_conductor` int(11) NOT NULL,
  `apellidosnombre` varchar(255) NOT NULL,
  `doc` varchar(4) DEFAULT NULL,
  `identificacion` varchar(15) DEFAULT NULL,
  `nacionalidad` varchar(40) DEFAULT NULL,
  `fechanacimiento` date DEFAULT NULL,
  `sexo` varchar(2) DEFAULT NULL,
  `gravedadmuerto` tinyint(1) DEFAULT NULL,
  `gravedadherido` tinyint(1) DEFAULT NULL,
  `direcciondomicilio` varchar(255) DEFAULT NULL,
  `ciudad` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `autorizosi` tinyint(1) DEFAULT NULL,
  `autorizono` tinyint(1) DEFAULT NULL,
  `sitioatencion` varchar(255) DEFAULT NULL,
  `deslesiones` varchar(255) DEFAULT NULL,
  `cvp_id_cvp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conductoranexo1`
--

CREATE TABLE `conductoranexo1` (
  `id_conductor` int(11) NOT NULL,
  `apellidosnombre` varchar(255) NOT NULL,
  `doc` varchar(4) DEFAULT NULL,
  `identificacion` varchar(15) DEFAULT NULL,
  `nacionalidad` varchar(40) DEFAULT NULL,
  `fechanacimiento` date DEFAULT NULL,
  `sexo` varchar(2) DEFAULT NULL,
  `gravedadmuerto` tinyint(1) DEFAULT NULL,
  `gravedadherido` tinyint(1) DEFAULT NULL,
  `direcciondomicilio` varchar(255) DEFAULT NULL,
  `ciudad` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `autorizosi` tinyint(1) DEFAULT NULL,
  `autorizono` tinyint(1) DEFAULT NULL,
  `sitioatencion` varchar(255) DEFAULT NULL,
  `deslesiones` varchar(255) DEFAULT NULL,
  `cvpanexo1_id_cvp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conductoresvehiculospropietarios`
--

CREATE TABLE `conductoresvehiculospropietarios` (
  `id_conductoresvehiculospropietarios` int(11) NOT NULL,
  `informepolicial_id_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conductoresvehiculospropietariosanexo1`
--

CREATE TABLE `conductoresvehiculospropietariosanexo1` (
  `id_conductoresvehiculospropietarios` int(11) NOT NULL,
  `anexo1_id_anexo1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `controlestransito`
--

CREATE TABLE `controlestransito` (
  `id_controlestransito` int(11) NOT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `correspondio`
--

CREATE TABLE `correspondio` (
  `id_correspondioanexo1` int(11) NOT NULL,
  `numeroinvestigacion` int(11) DEFAULT NULL,
  `anexo1_id_anexo1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `correspondioanexo2`
--

CREATE TABLE `correspondioanexo2` (
  `id_correspondioanexo2` int(11) NOT NULL,
  `numeroinvestigacion` int(11) DEFAULT NULL,
  `anexo2_id_anexo2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `correspondiocroquis`
--

CREATE TABLE `correspondiocroquis` (
  `id_correspondioanexo2` int(11) NOT NULL,
  `numeroinvestigacion` int(11) DEFAULT NULL,
  `croquis_id_croquis` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `croquis`
--

CREATE TABLE `croquis` (
  `id_croquis` int(11) NOT NULL,
  `numero` int(11) DEFAULT NULL,
  `x_a` int(11) DEFAULT NULL,
  `y_b` int(11) DEFAULT NULL,
  `identificacionplano` varchar(200) DEFAULT NULL,
  `itboy_itboy_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datosquienconoceaccidente`
--

CREATE TABLE `datosquienconoceaccidente` (
  `id_dqca` int(11) NOT NULL,
  `grado` int(11) DEFAULT NULL,
  `apellidosnombres` varchar(255) DEFAULT NULL,
  `doc` varchar(3) DEFAULT NULL,
  `numero` varchar(15) DEFAULT NULL,
  `placa` varchar(8) DEFAULT NULL,
  `entidad` varchar(100) DEFAULT NULL,
  `firma` varchar(255) DEFAULT NULL,
  `anexo1_id_anexo1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datosquienconoceaccidenteanexo2`
--

CREATE TABLE `datosquienconoceaccidenteanexo2` (
  `id_dqca` int(11) NOT NULL,
  `grado` int(11) DEFAULT NULL,
  `apellidosnombres` varchar(255) DEFAULT NULL,
  `doc` varchar(3) DEFAULT NULL,
  `numero` varchar(15) DEFAULT NULL,
  `placa` varchar(8) DEFAULT NULL,
  `entidad` varchar(100) DEFAULT NULL,
  `firma` varchar(255) DEFAULT NULL,
  `anexo2_id_anexo2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datosquienconoceaccidentecroquis`
--

CREATE TABLE `datosquienconoceaccidentecroquis` (
  `id_dqca` int(11) NOT NULL,
  `grado` int(11) DEFAULT NULL,
  `apellidosnombres` varchar(255) DEFAULT NULL,
  `doc` varchar(3) DEFAULT NULL,
  `numero` varchar(15) DEFAULT NULL,
  `placa` varchar(8) DEFAULT NULL,
  `entidad` varchar(100) DEFAULT NULL,
  `firma` varchar(255) DEFAULT NULL,
  `croquis_id_croquis` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `delineadorpiso`
--

CREATE TABLE `delineadorpiso` (
  `id_delineadorpiso` int(11) NOT NULL,
  `tacha` tinyint(1) DEFAULT NULL,
  `estoperoles` tinyint(1) DEFAULT NULL,
  `tachones` tinyint(1) DEFAULT NULL,
  `boyas` tinyint(1) DEFAULT NULL,
  `bordillos` tinyint(1) DEFAULT NULL,
  `tubular` tinyint(1) DEFAULT NULL,
  `barrerasplasticas` tinyint(1) DEFAULT NULL,
  `hitostubulares` tinyint(1) DEFAULT NULL,
  `conos` tinyint(1) DEFAULT NULL,
  `otros` varchar(255) DEFAULT NULL,
  `controlestransito_id_controlestransito` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallesvictima`
--

CREATE TABLE `detallesvictima` (
  `id_victimadetalles` int(11) NOT NULL,
  `examen` tinyint(1) DEFAULT NULL,
  `autorizo` tinyint(1) DEFAULT NULL,
  `suspsicoactivas` tinyint(1) DEFAULT NULL,
  `sitioatencion` varchar(255) DEFAULT NULL,
  `descripcionlesiones` varchar(255) DEFAULT NULL,
  `victimas_id_victimasanexo2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `diseno`
--

CREATE TABLE `diseno` (
  `id_diseno` int(11) NOT NULL,
  `glorieta` tinyint(1) DEFAULT NULL,
  `interseccion` tinyint(1) DEFAULT NULL,
  `lotepredio` tinyint(1) DEFAULT NULL,
  `pasonivel` tinyint(1) DEFAULT NULL,
  `ponton` tinyint(1) DEFAULT NULL,
  `cicloruta` tinyint(1) DEFAULT NULL,
  `pasoelevado` tinyint(1) DEFAULT NULL,
  `pasoinferior` tinyint(1) DEFAULT NULL,
  `peatonal` tinyint(1) DEFAULT NULL,
  `puente` tinyint(1) DEFAULT NULL,
  `tramodevia` tinyint(1) DEFAULT NULL,
  `tunel` tinyint(1) DEFAULT NULL,
  `caracteristicaslugar_id_caraclugar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `embriaguez`
--

CREATE TABLE `embriaguez` (
  `id_conductorembriaguez` int(11) NOT NULL,
  `positivo` tinyint(1) DEFAULT NULL,
  `negativo` tinyint(1) DEFAULT NULL,
  `grado` int(11) DEFAULT NULL,
  `conductor_id_conductor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `embriaguezanexo1`
--

CREATE TABLE `embriaguezanexo1` (
  `id_conductorembriaguez` int(11) NOT NULL,
  `positivo` tinyint(1) DEFAULT NULL,
  `negativo` tinyint(1) DEFAULT NULL,
  `grado` int(11) DEFAULT NULL,
  `conductoranexo1_id_conductor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `embriaguezvictima`
--

CREATE TABLE `embriaguezvictima` (
  `id_victimaembriaguez` int(11) DEFAULT NULL,
  `pos` tinyint(1) DEFAULT NULL,
  `neg` tinyint(1) DEFAULT NULL,
  `grado` int(11) DEFAULT NULL,
  `detallesvictima_id_victimadetalles` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `id_estado` int(11) NOT NULL,
  `bueno` tinyint(1) DEFAULT NULL,
  `conhuecos` tinyint(1) DEFAULT NULL,
  `derrumbes` tinyint(1) DEFAULT NULL,
  `enreparacion` tinyint(1) DEFAULT NULL,
  `hundimiento` tinyint(1) DEFAULT NULL,
  `inundada` tinyint(1) DEFAULT NULL,
  `parchada` tinyint(1) DEFAULT NULL,
  `rizada` tinyint(1) DEFAULT NULL,
  `fisurada` tinyint(1) DEFAULT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examen`
--

CREATE TABLE `examen` (
  `id_conductorexamen` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `conductor_id_conductor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examenanexo1`
--

CREATE TABLE `examenanexo1` (
  `id_conductorexamen` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `conductoranexo1_id_conductor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fallas`
--

CREATE TABLE `fallas` (
  `id_fallasvehiculo` int(11) NOT NULL,
  `frenos` tinyint(1) DEFAULT NULL,
  `direccion` tinyint(1) DEFAULT NULL,
  `luces` tinyint(1) DEFAULT NULL,
  `bocina` tinyint(1) DEFAULT NULL,
  `llantas` tinyint(1) DEFAULT NULL,
  `suspension` tinyint(1) DEFAULT NULL,
  `otra` varchar(255) DEFAULT NULL,
  `informepolicial_id_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `geometricas`
--

CREATE TABLE `geometricas` (
  `id_geometricas` int(11) NOT NULL,
  `recta` tinyint(1) DEFAULT NULL,
  `cruba` tinyint(1) DEFAULT NULL,
  `plano` tinyint(1) DEFAULT NULL,
  `pendiente` tinyint(1) DEFAULT NULL,
  `bahiaest` tinyint(1) DEFAULT NULL,
  `bahiaanden` tinyint(1) DEFAULT NULL,
  `bahiaberma` tinyint(1) DEFAULT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gravedad`
--

CREATE TABLE `gravedad` (
  `id_gravedad` int(11) NOT NULL,
  `muerto` tinyint(1) DEFAULT NULL,
  `herido` tinyint(1) DEFAULT NULL,
  `detallesvictima_id_victimadetalles` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hipotesisiaccidente`
--

CREATE TABLE `hipotesisiaccidente` (
  `id_hipotesisaccidente` int(11) NOT NULL,
  `delconductor` varchar(255) DEFAULT NULL,
  `delvehiculo` varchar(255) DEFAULT NULL,
  `devia` varchar(255) DEFAULT NULL,
  `delpeaton` varchar(255) DEFAULT NULL,
  `delpasajero` varchar(255) DEFAULT NULL,
  `otra` varchar(255) DEFAULT NULL,
  `anexo1_id_anexo1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iluminacionartificial`
--

CREATE TABLE `iluminacionartificial` (
  `id_iluminacionartificial` int(11) NOT NULL,
  `con` tinyint(1) DEFAULT NULL,
  `buena` tinyint(1) DEFAULT NULL,
  `mala` tinyint(1) DEFAULT NULL,
  `sin` tinyint(1) DEFAULT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `informepolicial`
--

CREATE TABLE `informepolicial` (
  `id_informe` int(11) NOT NULL,
  `coogeograficas` varchar(8) NOT NULL,
  `fechahoraocurrencia` date NOT NULL,
  `fechahoralevantamiento` date NOT NULL,
  `localidadcomuna` varchar(255) NOT NULL,
  `id_informe1` int(11) NOT NULL,
  `itboy_itboy_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `itboy`
--

CREATE TABLE `itboy` (
  `id_casoaccidente` int(11) DEFAULT NULL,
  `id_informe` int(11) NOT NULL,
  `itboy_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `licencia`
--

CREATE TABLE `licencia` (
  `id_conductorlicencia` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `numerolicencia` varchar(255) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `restriccion` varchar(50) DEFAULT NULL,
  `exp` tinyint(1) DEFAULT NULL,
  `ven` tinyint(1) DEFAULT NULL,
  `diaexpven` date DEFAULT NULL,
  `codigotransito` varchar(255) DEFAULT NULL,
  `chalecosi` tinyint(1) DEFAULT NULL,
  `chalecono` tinyint(1) DEFAULT NULL,
  `cascosi` tinyint(1) DEFAULT NULL,
  `cascono` tinyint(1) DEFAULT NULL,
  `cinturonsi` tinyint(1) DEFAULT NULL,
  `cinturonno` tinyint(1) DEFAULT NULL,
  `conductor_id_conductor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `licenciaanexo1`
--

CREATE TABLE `licenciaanexo1` (
  `id_conductorlicencia` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `numerolicencia` varchar(255) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `restriccion` varchar(50) DEFAULT NULL,
  `exp` tinyint(1) DEFAULT NULL,
  `ven` tinyint(1) DEFAULT NULL,
  `diaexpven` date DEFAULT NULL,
  `codigotransito` varchar(255) DEFAULT NULL,
  `chalecosi` tinyint(1) DEFAULT NULL,
  `chalecono` tinyint(1) DEFAULT NULL,
  `cascosi` tinyint(1) DEFAULT NULL,
  `cascono` tinyint(1) DEFAULT NULL,
  `cinturonsi` tinyint(1) DEFAULT NULL,
  `cinturonno` tinyint(1) DEFAULT NULL,
  `conductoranexo1_id_conductor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `longhuellas`
--

CREATE TABLE `longhuellas` (
  `id_longhuellas` int(11) NOT NULL,
  `numero` int(11) DEFAULT NULL,
  `metros` int(11) DEFAULT NULL,
  `cm` int(11) DEFAULT NULL,
  `tipohuella` varchar(255) DEFAULT NULL,
  `croquis_id_croquis` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugarimpacto`
--

CREATE TABLE `lugarimpacto` (
  `id_lugarimpacto` int(11) NOT NULL,
  `frontal` tinyint(1) DEFAULT NULL,
  `lateral` tinyint(1) DEFAULT NULL,
  `posterior` tinyint(1) DEFAULT NULL,
  `otro` varchar(255) DEFAULT NULL,
  `fallas_id_fallasvehiculo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mismoconductor`
--

CREATE TABLE `mismoconductor` (
  `id_propietarioconductor` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `apellidonombre_1` varchar(255) DEFAULT NULL,
  `doc` varchar(4) DEFAULT NULL,
  `identificacion` varchar(25) DEFAULT NULL,
  `descripciopnda�osmateriales` varchar(255) DEFAULT NULL,
  `propietario_id_propietario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mixto`
--

CREATE TABLE `mixto` (
  `id_mixto` int(11) NOT NULL,
  `mixto` tinyint(1) DEFAULT NULL,
  `modalidadtrans_id_modtrans` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modalidadtrans`
--

CREATE TABLE `modalidadtrans` (
  `id_modtrans` int(11) NOT NULL,
  `mixto` tinyint(1) DEFAULT NULL,
  `vehiculopropietario_id_propietarioclasevehiculo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nacionalidad`
--

CREATE TABLE `nacionalidad` (
  `id_vehiculonacionalidad` int(11) NOT NULL,
  `colombiano` tinyint(1) DEFAULT NULL,
  `extranjero` tinyint(1) DEFAULT NULL,
  `vehiculo_vehiculo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nacionalidadanexo1`
--

CREATE TABLE `nacionalidadanexo1` (
  `id_vehiculonacionalidad` int(11) NOT NULL,
  `colombiano` tinyint(1) DEFAULT NULL,
  `extranjero` tinyint(1) DEFAULT NULL,
  `vehiculoanexo1_vehiculoanexo1_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `observaciones`
--

CREATE TABLE `observaciones` (
  `id_observaciones` int(11) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `anexo2_id_anexo2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pasajeros`
--

CREATE TABLE `pasajeros` (
  `id_pasajerospropietario` int(11) NOT NULL,
  `colectivo` tinyint(1) DEFAULT NULL,
  `individual` tinyint(1) DEFAULT NULL,
  `masivo` tinyint(1) DEFAULT NULL,
  `especialturismo` tinyint(1) DEFAULT NULL,
  `especialescolar` tinyint(1) DEFAULT NULL,
  `especialasalariado` tinyint(1) DEFAULT NULL,
  `especialocasional` tinyint(1) DEFAULT NULL,
  `modalidadtrans_id_modtrans` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `poliza`
--

CREATE TABLE `poliza` (
  `id_vehiculopoliza` int(11) NOT NULL,
  `polizanum` varchar(255) DEFAULT NULL,
  `aseguradora` varchar(255) DEFAULT NULL,
  `vencimineto` date DEFAULT NULL,
  `vehiculo_vehiculo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `polizaanexo1`
--

CREATE TABLE `polizaanexo1` (
  `id_vehiculopoliza` int(11) NOT NULL,
  `polizanum` varchar(255) DEFAULT NULL,
  `aseguradora` varchar(255) DEFAULT NULL,
  `vencimineto` date DEFAULT NULL,
  `vehiculoanexo1_vehiculoanexo1_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `propietario`
--

CREATE TABLE `propietario` (
  `id_propietario` int(11) NOT NULL,
  `informepolicial_id_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `radioaccion`
--

CREATE TABLE `radioaccion` (
  `id_radioaccion` int(11) DEFAULT NULL,
  `nacional` tinyint(1) DEFAULT NULL,
  `municipal` tinyint(1) DEFAULT NULL,
  `vehiculopropietario_id_propietarioclasevehiculo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reductorvelocidad`
--

CREATE TABLE `reductorvelocidad` (
  `id_reductorvelocidad` int(11) NOT NULL,
  `bandassonoras` tinyint(1) DEFAULT NULL,
  `resaltomovil` tinyint(1) DEFAULT NULL,
  `resaltofijo` tinyint(1) DEFAULT NULL,
  `sonorizador` tinyint(1) DEFAULT NULL,
  `estoperol` tinyint(1) DEFAULT NULL,
  `otro` varchar(255) DEFAULT NULL,
  `controlestransito_id_controlestransito` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsabilidadcivilcontractual`
--

CREATE TABLE `responsabilidadcivilcontractual` (
  `id_rcc` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `aseguradora` varchar(255) DEFAULT NULL,
  `vencimiento` date DEFAULT NULL,
  `vehiculo_vehiculo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsabilidadcivilcontractualanexo1`
--

CREATE TABLE `responsabilidadcivilcontractualanexo1` (
  `id_rcc` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `aseguradora` varchar(255) DEFAULT NULL,
  `vencimiento` date DEFAULT NULL,
  `vehiculoanexo1_vehiculoanexo1_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsabilidadextracondicional`
--

CREATE TABLE `responsabilidadextracondicional` (
  `id_re` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `aseguradora` varchar(255) DEFAULT NULL,
  `vencimiento` date DEFAULT NULL,
  `vehiculo_vehiculo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsabilidadextracondicionalanexo1`
--

CREATE TABLE `responsabilidadextracondicionalanexo1` (
  `id_re` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `aseguradora` varchar(255) DEFAULT NULL,
  `vencimiento` date DEFAULT NULL,
  `vehiculoanexo1_vehiculoanexo1_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revtecmec`
--

CREATE TABLE `revtecmec` (
  `id_revisionvehiculo` int(11) DEFAULT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `vehiculo_vehiculo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revtecmecanexo1`
--

CREATE TABLE `revtecmecanexo1` (
  `id_revisionvehiculo` int(11) DEFAULT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `vehiculoanexo1_vehiculoanexo1_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sector`
--

CREATE TABLE `sector` (
  `id_sector` int(11) NOT NULL,
  `residencial` tinyint(1) DEFAULT NULL,
  `industrial` int(11) DEFAULT NULL,
  `comercial` int(11) DEFAULT NULL,
  `caracteristicaslugar_id_caraclugar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `semaforo`
--

CREATE TABLE `semaforo` (
  `id_ctsemaforo` int(11) DEFAULT NULL,
  `operando` tinyint(1) DEFAULT NULL,
  `intermitente` tinyint(1) DEFAULT NULL,
  `condanos` tinyint(1) DEFAULT NULL,
  `apagado` tinyint(1) DEFAULT NULL,
  `oculto` tinyint(1) DEFAULT NULL,
  `controlestransito_id_controlestransito` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `senaleshorizontales`
--

CREATE TABLE `senaleshorizontales` (
  `id_senaleshorizontales` int(11) NOT NULL,
  `zonapeatonal` tinyint(1) DEFAULT NULL,
  `lineapare` tinyint(1) DEFAULT NULL,
  `lineacentralamarillacontinua` tinyint(1) DEFAULT NULL,
  `lineacentralamarillasegmentada` tinyint(1) DEFAULT NULL,
  `lineacarrilblancacontinua` tinyint(1) DEFAULT NULL,
  `lineacarrilblancasegmentada` tinyint(1) DEFAULT NULL,
  `lineacarrilblancalba` tinyint(1) DEFAULT NULL,
  `lineacarrilblancala` tinyint(1) DEFAULT NULL,
  `flechas` tinyint(1) DEFAULT NULL,
  `leyendas` tinyint(1) DEFAULT NULL,
  `simbolos` tinyint(1) DEFAULT NULL,
  `otrasenal` varchar(255) DEFAULT NULL,
  `controlestransito_id_controlestransito` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `senalesverticales`
--

CREATE TABLE `senalesverticales` (
  `id_senalesverticales` int(11) NOT NULL,
  `depare` tinyint(1) DEFAULT NULL,
  `cedaelpaso` tinyint(1) DEFAULT NULL,
  `denogire` tinyint(1) DEFAULT NULL,
  `desentidovial` tinyint(1) DEFAULT NULL,
  `denoadelantar` tinyint(1) DEFAULT NULL,
  `develocidadmax` tinyint(1) DEFAULT NULL,
  `otra` varchar(255) DEFAULT NULL,
  `ninguna` tinyint(1) DEFAULT NULL,
  `controlestransito_id_controlestransito` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `soat`
--

CREATE TABLE `soat` (
  `id_vehiculosoat` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `vehiculo_vehiculo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `soatanexo1`
--

CREATE TABLE `soatanexo1` (
  `id_vehiculosoat` int(11) NOT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `vehiculoanexo1_vehiculoanexo1_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `superficierodadura`
--

CREATE TABLE `superficierodadura` (
  `id_superficierodadura` int(11) NOT NULL,
  `asfalto` tinyint(1) DEFAULT NULL,
  `afirmado` tinyint(1) DEFAULT NULL,
  `adoquin` tinyint(1) DEFAULT NULL,
  `empredado` tinyint(1) DEFAULT NULL,
  `concreto` tinyint(1) DEFAULT NULL,
  `tierra` tinyint(1) DEFAULT NULL,
  `otro` varchar(255) DEFAULT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `suspsicoactivas`
--

CREATE TABLE `suspsicoactivas` (
  `id_conductorspsicoactivas` int(11) DEFAULT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `conductor_id_conductor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `suspsicoactivasanexo1`
--

CREATE TABLE `suspsicoactivasanexo1` (
  `id_conductorspsicoactivas` int(11) DEFAULT NULL,
  `si` tinyint(1) DEFAULT NULL,
  `no` tinyint(1) DEFAULT NULL,
  `conductoranexo1_id_conductor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `utilizacion`
--

CREATE TABLE `utilizacion` (
  `id_ustilizacion` int(11) NOT NULL,
  `unsentido` tinyint(1) DEFAULT NULL,
  `doblesentido` tinyint(1) DEFAULT NULL,
  `reversible` tinyint(1) DEFAULT NULL,
  `contraflujo` tinyint(1) DEFAULT NULL,
  `ciclovia` tinyint(1) DEFAULT NULL,
  `via2_id_caracvia2` int(11) NOT NULL,
  `via1_id_caracvia1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo`
--

CREATE TABLE `vehiculo` (
  `id_vehiculo` int(11) DEFAULT NULL,
  `placa` varchar(8) DEFAULT NULL,
  `placaremolque` varchar(10) DEFAULT NULL,
  `marca` varchar(10) DEFAULT NULL,
  `linea` varchar(10) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `modelo` varchar(10) DEFAULT NULL,
  `carroceria` varchar(10) DEFAULT NULL,
  `ton` varchar(10) DEFAULT NULL,
  `numpasajeros` int(11) DEFAULT NULL,
  `licenciatrans` int(11) DEFAULT NULL,
  `empresa` varchar(255) DEFAULT NULL,
  `matriculadoen` varchar(255) DEFAULT NULL,
  `inmovilizadoen` varchar(255) DEFAULT NULL,
  `adisposicionde` varchar(255) DEFAULT NULL,
  `tarjetasregistro` varchar(255) DEFAULT NULL,
  `nit` varchar(255) DEFAULT NULL,
  `cvp_id_cvp` int(11) NOT NULL,
  `vehiculo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculoanexo1`
--

CREATE TABLE `vehiculoanexo1` (
  `id_vehiculo` int(11) DEFAULT NULL,
  `placa` varchar(8) DEFAULT NULL,
  `placaremolque` varchar(10) DEFAULT NULL,
  `marca` varchar(10) DEFAULT NULL,
  `linea` varchar(10) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `modelo` varchar(10) DEFAULT NULL,
  `carroceria` varchar(10) DEFAULT NULL,
  `ton` varchar(10) DEFAULT NULL,
  `numpasajeros` int(11) DEFAULT NULL,
  `licenciatrans` int(11) DEFAULT NULL,
  `empresa` varchar(255) DEFAULT NULL,
  `matriculadoen` varchar(255) DEFAULT NULL,
  `inmovilizadoen` varchar(255) DEFAULT NULL,
  `adisposicionde` varchar(255) DEFAULT NULL,
  `tarjetasregistro` varchar(255) DEFAULT NULL,
  `nit` varchar(255) DEFAULT NULL,
  `cvpanexo1_id_cvp` int(11) NOT NULL,
  `vehiculoanexo1_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculopropietario`
--

CREATE TABLE `vehiculopropietario` (
  `id_propietarioclasevehiculo` int(11) NOT NULL,
  `automovil` tinyint(1) DEFAULT NULL,
  `bus` tinyint(1) DEFAULT NULL,
  `buseta` tinyint(1) DEFAULT NULL,
  `camion` tinyint(1) DEFAULT NULL,
  `camioneta` tinyint(1) DEFAULT NULL,
  `campero` tinyint(1) DEFAULT NULL,
  `microbus` tinyint(1) DEFAULT NULL,
  `tractocamion` tinyint(1) DEFAULT NULL,
  `volqueta` tinyint(1) DEFAULT NULL,
  `motocicleta` tinyint(1) DEFAULT NULL,
  `m_agricola` tinyint(1) DEFAULT NULL,
  `m_industrial` tinyint(1) DEFAULT NULL,
  `bicicleta` tinyint(1) DEFAULT NULL,
  `motocarro` tinyint(1) DEFAULT NULL,
  `traccion_animal` tinyint(1) DEFAULT NULL,
  `motociclo` tinyint(1) DEFAULT NULL,
  `cuatrimoto` tinyint(1) DEFAULT NULL,
  `remolque` tinyint(1) DEFAULT NULL,
  `semi_remolque` tinyint(1) DEFAULT NULL,
  `propietario_id_propietario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `via1`
--

CREATE TABLE `via1` (
  `id_caracvia1` int(11) NOT NULL,
  `caracteristicasvia_id_caracvia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `via1croquis`
--

CREATE TABLE `via1croquis` (
  `id_via1` int(11) NOT NULL,
  `radio` int(11) DEFAULT NULL,
  `peralte` int(11) DEFAULT NULL,
  `pendiente` int(11) DEFAULT NULL,
  `croquis_id_croquis` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `via2`
--

CREATE TABLE `via2` (
  `id_caracvia2` int(11) NOT NULL,
  `caracteristicasvia_id_caracvia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `via2croquis`
--

CREATE TABLE `via2croquis` (
  `id_via2` int(11) NOT NULL,
  `radio` int(11) DEFAULT NULL,
  `peralte` int(11) DEFAULT NULL,
  `pendiente` int(11) DEFAULT NULL,
  `croquis_id_croquis` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `victimas`
--

CREATE TABLE `victimas` (
  `id_victimasanexo2` int(11) NOT NULL,
  `apellidosnombres` varchar(255) DEFAULT NULL,
  `doc` varchar(4) DEFAULT NULL,
  `identificacion` varchar(15) DEFAULT NULL,
  `nacionalidad` varchar(50) DEFAULT NULL,
  `fechanacimiento` date DEFAULT NULL,
  `direcciondomicilio` varchar(100) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT NULL,
  `telefono` varchar(100) DEFAULT NULL,
  `cinturon` tinyint(1) DEFAULT NULL,
  `casco` tinyint(1) DEFAULT NULL,
  `chaleco` tinyint(1) DEFAULT NULL,
  `anexo2_id_anexo2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visibilidad`
--

CREATE TABLE `visibilidad` (
  `id_visibilidad` int(11) NOT NULL,
  `normal` tinyint(1) DEFAULT NULL,
  `disminuidaporcasetas` tinyint(1) DEFAULT NULL,
  `disminuidaporconstruccion` tinyint(1) DEFAULT NULL,
  `disminuidaporvallas` tinyint(1) DEFAULT NULL,
  `disminuidaporarbolvegetacion` tinyint(1) DEFAULT NULL,
  `disminuidaporvehiculoestacionado` tinyint(1) DEFAULT NULL,
  `disminuidaporencadilamiento` tinyint(1) DEFAULT NULL,
  `disminuidaporposte` tinyint(1) DEFAULT NULL,
  `otros` varchar(255) DEFAULT NULL,
  `via1_id_caracvia1` int(11) NOT NULL,
  `via2_id_caracvia2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zona`
--

CREATE TABLE `zona` (
  `id_zona` int(11) NOT NULL,
  `escolar` tinyint(1) DEFAULT NULL,
  `turistica` tinyint(1) DEFAULT NULL,
  `militar` tinyint(1) DEFAULT NULL,
  `deportiva` tinyint(1) DEFAULT NULL,
  `privada` tinyint(1) DEFAULT NULL,
  `hospitalaria` tinyint(1) DEFAULT NULL,
  `caracteristicaslugar_id_caraclugar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `agentetransito`
--
ALTER TABLE `agentetransito`
  ADD PRIMARY KEY (`id_agentetransito`),
  ADD UNIQUE KEY `agentetransito__idx` (`controlestransito_id_controlestransito`);

--
-- Indices de la tabla `anexo1`
--
ALTER TABLE `anexo1`
  ADD PRIMARY KEY (`id_anexo1`),
  ADD KEY `anexo1_itboy_fk` (`itboy_itboy_id`);

--
-- Indices de la tabla `anexo2`
--
ALTER TABLE `anexo2`
  ADD PRIMARY KEY (`id_anexo2`),
  ADD KEY `anexo2_itboy_fk` (`itboy_itboy_id`);

--
-- Indices de la tabla `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`id_area`),
  ADD UNIQUE KEY `area__idx` (`caracteristicaslugar_id_caraclugar`);

--
-- Indices de la tabla `calzadas`
--
ALTER TABLE `calzadas`
  ADD PRIMARY KEY (`id_calzada`),
  ADD UNIQUE KEY `calzadas__idx` (`via2_id_caracvia2`),
  ADD UNIQUE KEY `calzadas__idxv1` (`via1_id_caracvia1`);

--
-- Indices de la tabla `caracteristicaslugar`
--
ALTER TABLE `caracteristicaslugar`
  ADD PRIMARY KEY (`id_caraclugar`),
  ADD UNIQUE KEY `caracteristicaslugar__idx` (`informepolicial_id_informe`);

--
-- Indices de la tabla `caracteristicasvia`
--
ALTER TABLE `caracteristicasvia`
  ADD PRIMARY KEY (`id_caracvia`),
  ADD UNIQUE KEY `caracteristicasvia__idx` (`informepolicial_id_informe`);

--
-- Indices de la tabla `carga`
--
ALTER TABLE `carga`
  ADD PRIMARY KEY (`id_carga`),
  ADD UNIQUE KEY `carga__idx` (`modalidadtrans_id_modtrans`);

--
-- Indices de la tabla `carriles`
--
ALTER TABLE `carriles`
  ADD PRIMARY KEY (`id_carriles`),
  ADD UNIQUE KEY `carriles__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `carriles__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `choqueobjeto`
--
ALTER TABLE `choqueobjeto`
  ADD PRIMARY KEY (`id_choqueobjeto`),
  ADD KEY `choqueobjeto_claseaccidente_fk` (`claseaccidente_id_claseaccidente`,`claseaccidente_id_informe`);

--
-- Indices de la tabla `choqueobjetofijo`
--
ALTER TABLE `choqueobjetofijo`
  ADD PRIMARY KEY (`id_choqueobjeto`),
  ADD KEY `choqueobjetofijo_claseaccidente_fk` (`claseaccidente_id_claseaccidente`,`claseaccidente_id_informe`);

--
-- Indices de la tabla `claseaccidente`
--
ALTER TABLE `claseaccidente`
  ADD PRIMARY KEY (`id_claseaccidente`,`informepolicial_id_informe`),
  ADD KEY `claseaccidente_informepolicial_fk` (`informepolicial_id_informe`);

--
-- Indices de la tabla `claseservicio`
--
ALTER TABLE `claseservicio`
  ADD PRIMARY KEY (`id_claseservicio`),
  ADD UNIQUE KEY `claseservicio__idx` (`vehiculopropietario_id_propietarioclasevehiculo`);

--
-- Indices de la tabla `condicion`
--
ALTER TABLE `condicion`
  ADD PRIMARY KEY (`id_detallescondicion`),
  ADD UNIQUE KEY `condicion__idx` (`detallesvictima_id_victimadetalles`);

--
-- Indices de la tabla `condicionclimatica`
--
ALTER TABLE `condicionclimatica`
  ADD PRIMARY KEY (`id_condicionesclima`),
  ADD UNIQUE KEY `condicionclimatica__idx` (`caracteristicaslugar_id_caraclugar`);

--
-- Indices de la tabla `condiciones`
--
ALTER TABLE `condiciones`
  ADD PRIMARY KEY (`id_condiciones`),
  ADD UNIQUE KEY `condiciones__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `condiciones__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `conductor`
--
ALTER TABLE `conductor`
  ADD PRIMARY KEY (`id_conductor`),
  ADD UNIQUE KEY `conductor__idx` (`cvp_id_cvp`);

--
-- Indices de la tabla `conductoranexo1`
--
ALTER TABLE `conductoranexo1`
  ADD PRIMARY KEY (`id_conductor`),
  ADD UNIQUE KEY `conductoranexo1__idx` (`cvpanexo1_id_cvp`);

--
-- Indices de la tabla `conductoresvehiculospropietarios`
--
ALTER TABLE `conductoresvehiculospropietarios`
  ADD PRIMARY KEY (`id_conductoresvehiculospropietarios`),
  ADD UNIQUE KEY `conductoresvehiculospropietarios__idx` (`informepolicial_id_informe`);

--
-- Indices de la tabla `conductoresvehiculospropietariosanexo1`
--
ALTER TABLE `conductoresvehiculospropietariosanexo1`
  ADD PRIMARY KEY (`id_conductoresvehiculospropietarios`),
  ADD UNIQUE KEY `conductoresvehiculospropietariosanexo1__idx` (`anexo1_id_anexo1`);

--
-- Indices de la tabla `controlestransito`
--
ALTER TABLE `controlestransito`
  ADD PRIMARY KEY (`id_controlestransito`),
  ADD UNIQUE KEY `controlestransito__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `controlestransito__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `correspondio`
--
ALTER TABLE `correspondio`
  ADD PRIMARY KEY (`id_correspondioanexo1`),
  ADD UNIQUE KEY `correspondio__idx` (`anexo1_id_anexo1`);

--
-- Indices de la tabla `correspondioanexo2`
--
ALTER TABLE `correspondioanexo2`
  ADD PRIMARY KEY (`id_correspondioanexo2`),
  ADD UNIQUE KEY `correspondioanexo2__idx` (`anexo2_id_anexo2`);

--
-- Indices de la tabla `correspondiocroquis`
--
ALTER TABLE `correspondiocroquis`
  ADD PRIMARY KEY (`id_correspondioanexo2`),
  ADD UNIQUE KEY `correspondiocroquis__idx` (`croquis_id_croquis`);

--
-- Indices de la tabla `croquis`
--
ALTER TABLE `croquis`
  ADD PRIMARY KEY (`id_croquis`),
  ADD KEY `croquis_itboy_fk` (`itboy_itboy_id`);

--
-- Indices de la tabla `datosquienconoceaccidente`
--
ALTER TABLE `datosquienconoceaccidente`
  ADD PRIMARY KEY (`id_dqca`),
  ADD UNIQUE KEY `datosquienconoceaccidente__idx` (`anexo1_id_anexo1`);

--
-- Indices de la tabla `datosquienconoceaccidenteanexo2`
--
ALTER TABLE `datosquienconoceaccidenteanexo2`
  ADD PRIMARY KEY (`id_dqca`),
  ADD UNIQUE KEY `datosquienconoceaccidenteanexo2__idx` (`anexo2_id_anexo2`);

--
-- Indices de la tabla `datosquienconoceaccidentecroquis`
--
ALTER TABLE `datosquienconoceaccidentecroquis`
  ADD PRIMARY KEY (`id_dqca`),
  ADD UNIQUE KEY `datosquienconoceaccidentecroquis__idx` (`croquis_id_croquis`);

--
-- Indices de la tabla `delineadorpiso`
--
ALTER TABLE `delineadorpiso`
  ADD PRIMARY KEY (`id_delineadorpiso`),
  ADD UNIQUE KEY `delineadorpiso__idx` (`controlestransito_id_controlestransito`);

--
-- Indices de la tabla `detallesvictima`
--
ALTER TABLE `detallesvictima`
  ADD PRIMARY KEY (`id_victimadetalles`),
  ADD UNIQUE KEY `detallesvictima__idx` (`victimas_id_victimasanexo2`);

--
-- Indices de la tabla `diseno`
--
ALTER TABLE `diseno`
  ADD PRIMARY KEY (`id_diseno`),
  ADD UNIQUE KEY `diseno__idx` (`caracteristicaslugar_id_caraclugar`);

--
-- Indices de la tabla `embriaguez`
--
ALTER TABLE `embriaguez`
  ADD PRIMARY KEY (`id_conductorembriaguez`),
  ADD UNIQUE KEY `embriaguez__idx` (`conductor_id_conductor`);

--
-- Indices de la tabla `embriaguezanexo1`
--
ALTER TABLE `embriaguezanexo1`
  ADD PRIMARY KEY (`id_conductorembriaguez`),
  ADD UNIQUE KEY `embriaguezanexo1__idx` (`conductoranexo1_id_conductor`);

--
-- Indices de la tabla `embriaguezvictima`
--
ALTER TABLE `embriaguezvictima`
  ADD UNIQUE KEY `embriaguezvictima__idx` (`detallesvictima_id_victimadetalles`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`id_estado`),
  ADD UNIQUE KEY `estado__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `estado__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `examen`
--
ALTER TABLE `examen`
  ADD PRIMARY KEY (`id_conductorexamen`),
  ADD UNIQUE KEY `examen__idx` (`conductor_id_conductor`);

--
-- Indices de la tabla `examenanexo1`
--
ALTER TABLE `examenanexo1`
  ADD PRIMARY KEY (`id_conductorexamen`),
  ADD UNIQUE KEY `examenanexo1__idx` (`conductoranexo1_id_conductor`);

--
-- Indices de la tabla `fallas`
--
ALTER TABLE `fallas`
  ADD PRIMARY KEY (`id_fallasvehiculo`),
  ADD UNIQUE KEY `fallas__idx` (`informepolicial_id_informe`);

--
-- Indices de la tabla `geometricas`
--
ALTER TABLE `geometricas`
  ADD PRIMARY KEY (`id_geometricas`),
  ADD UNIQUE KEY `geometricas__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `geometricas__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `gravedad`
--
ALTER TABLE `gravedad`
  ADD PRIMARY KEY (`id_gravedad`),
  ADD UNIQUE KEY `gravedad__idx` (`detallesvictima_id_victimadetalles`);

--
-- Indices de la tabla `hipotesisiaccidente`
--
ALTER TABLE `hipotesisiaccidente`
  ADD PRIMARY KEY (`id_hipotesisaccidente`),
  ADD UNIQUE KEY `hipotesisiaccidente__idx` (`anexo1_id_anexo1`);

--
-- Indices de la tabla `iluminacionartificial`
--
ALTER TABLE `iluminacionartificial`
  ADD PRIMARY KEY (`id_iluminacionartificial`),
  ADD UNIQUE KEY `iluminacionartificial__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `iluminacionartificial__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `informepolicial`
--
ALTER TABLE `informepolicial`
  ADD PRIMARY KEY (`id_informe`),
  ADD KEY `informepolicial_itboy_fk` (`itboy_itboy_id`);

--
-- Indices de la tabla `itboy`
--
ALTER TABLE `itboy`
  ADD PRIMARY KEY (`itboy_id`);

--
-- Indices de la tabla `licencia`
--
ALTER TABLE `licencia`
  ADD PRIMARY KEY (`id_conductorlicencia`),
  ADD UNIQUE KEY `licencia__idx` (`conductor_id_conductor`);

--
-- Indices de la tabla `licenciaanexo1`
--
ALTER TABLE `licenciaanexo1`
  ADD PRIMARY KEY (`id_conductorlicencia`),
  ADD UNIQUE KEY `licenciaanexo1__idx` (`conductoranexo1_id_conductor`);

--
-- Indices de la tabla `longhuellas`
--
ALTER TABLE `longhuellas`
  ADD PRIMARY KEY (`id_longhuellas`),
  ADD UNIQUE KEY `longhuellas__idx` (`croquis_id_croquis`);

--
-- Indices de la tabla `lugarimpacto`
--
ALTER TABLE `lugarimpacto`
  ADD PRIMARY KEY (`id_lugarimpacto`),
  ADD UNIQUE KEY `lugarimpacto__idx` (`fallas_id_fallasvehiculo`);

--
-- Indices de la tabla `mismoconductor`
--
ALTER TABLE `mismoconductor`
  ADD PRIMARY KEY (`id_propietarioconductor`),
  ADD UNIQUE KEY `mismoconductor__idx` (`propietario_id_propietario`);

--
-- Indices de la tabla `mixto`
--
ALTER TABLE `mixto`
  ADD PRIMARY KEY (`id_mixto`),
  ADD UNIQUE KEY `mixto__idx` (`modalidadtrans_id_modtrans`);

--
-- Indices de la tabla `modalidadtrans`
--
ALTER TABLE `modalidadtrans`
  ADD PRIMARY KEY (`id_modtrans`),
  ADD UNIQUE KEY `modalidadtrans__idx` (`vehiculopropietario_id_propietarioclasevehiculo`);

--
-- Indices de la tabla `nacionalidad`
--
ALTER TABLE `nacionalidad`
  ADD PRIMARY KEY (`id_vehiculonacionalidad`),
  ADD UNIQUE KEY `nacionalidad__idx` (`vehiculo_vehiculo_id`);

--
-- Indices de la tabla `nacionalidadanexo1`
--
ALTER TABLE `nacionalidadanexo1`
  ADD PRIMARY KEY (`id_vehiculonacionalidad`),
  ADD UNIQUE KEY `nacionalidadanexo1__idx` (`vehiculoanexo1_vehiculoanexo1_id`);

--
-- Indices de la tabla `observaciones`
--
ALTER TABLE `observaciones`
  ADD UNIQUE KEY `observaciones__idx` (`anexo2_id_anexo2`);

--
-- Indices de la tabla `pasajeros`
--
ALTER TABLE `pasajeros`
  ADD PRIMARY KEY (`id_pasajerospropietario`),
  ADD UNIQUE KEY `pasajeros__idx` (`modalidadtrans_id_modtrans`);

--
-- Indices de la tabla `poliza`
--
ALTER TABLE `poliza`
  ADD PRIMARY KEY (`id_vehiculopoliza`),
  ADD UNIQUE KEY `poliza__idx` (`vehiculo_vehiculo_id`);

--
-- Indices de la tabla `polizaanexo1`
--
ALTER TABLE `polizaanexo1`
  ADD PRIMARY KEY (`id_vehiculopoliza`),
  ADD UNIQUE KEY `polizaanexo1__idx` (`vehiculoanexo1_vehiculoanexo1_id`);

--
-- Indices de la tabla `propietario`
--
ALTER TABLE `propietario`
  ADD PRIMARY KEY (`id_propietario`),
  ADD UNIQUE KEY `propietario__idx` (`informepolicial_id_informe`);

--
-- Indices de la tabla `radioaccion`
--
ALTER TABLE `radioaccion`
  ADD UNIQUE KEY `radioaccion__idx` (`vehiculopropietario_id_propietarioclasevehiculo`);

--
-- Indices de la tabla `reductorvelocidad`
--
ALTER TABLE `reductorvelocidad`
  ADD PRIMARY KEY (`id_reductorvelocidad`),
  ADD UNIQUE KEY `reductorvelocidad__idx` (`controlestransito_id_controlestransito`);

--
-- Indices de la tabla `responsabilidadcivilcontractual`
--
ALTER TABLE `responsabilidadcivilcontractual`
  ADD PRIMARY KEY (`id_rcc`),
  ADD UNIQUE KEY `responsabilidadcivilcontractual__idx` (`vehiculo_vehiculo_id`);

--
-- Indices de la tabla `responsabilidadcivilcontractualanexo1`
--
ALTER TABLE `responsabilidadcivilcontractualanexo1`
  ADD PRIMARY KEY (`id_rcc`),
  ADD UNIQUE KEY `responsabilidadcivilcontractualanexo1__idx` (`vehiculoanexo1_vehiculoanexo1_id`);

--
-- Indices de la tabla `responsabilidadextracondicional`
--
ALTER TABLE `responsabilidadextracondicional`
  ADD PRIMARY KEY (`id_re`),
  ADD UNIQUE KEY `responsabilidadextracondicional__idx` (`vehiculo_vehiculo_id`);

--
-- Indices de la tabla `responsabilidadextracondicionalanexo1`
--
ALTER TABLE `responsabilidadextracondicionalanexo1`
  ADD PRIMARY KEY (`id_re`),
  ADD UNIQUE KEY `responsabilidadextracondicionalanexo1__idx` (`vehiculoanexo1_vehiculoanexo1_id`);

--
-- Indices de la tabla `revtecmec`
--
ALTER TABLE `revtecmec`
  ADD UNIQUE KEY `revtecmec__idx` (`vehiculo_vehiculo_id`);

--
-- Indices de la tabla `revtecmecanexo1`
--
ALTER TABLE `revtecmecanexo1`
  ADD UNIQUE KEY `revtecmecanexo1__idx` (`vehiculoanexo1_vehiculoanexo1_id`);

--
-- Indices de la tabla `sector`
--
ALTER TABLE `sector`
  ADD PRIMARY KEY (`id_sector`),
  ADD UNIQUE KEY `sector__idx` (`caracteristicaslugar_id_caraclugar`);

--
-- Indices de la tabla `semaforo`
--
ALTER TABLE `semaforo`
  ADD UNIQUE KEY `semaforo__idx` (`controlestransito_id_controlestransito`);

--
-- Indices de la tabla `senaleshorizontales`
--
ALTER TABLE `senaleshorizontales`
  ADD PRIMARY KEY (`id_senaleshorizontales`),
  ADD UNIQUE KEY `senaleshorizontales__idx` (`controlestransito_id_controlestransito`);

--
-- Indices de la tabla `senalesverticales`
--
ALTER TABLE `senalesverticales`
  ADD PRIMARY KEY (`id_senalesverticales`),
  ADD UNIQUE KEY `senalesverticales__idx` (`controlestransito_id_controlestransito`);

--
-- Indices de la tabla `soat`
--
ALTER TABLE `soat`
  ADD PRIMARY KEY (`id_vehiculosoat`),
  ADD UNIQUE KEY `soat__idx` (`vehiculo_vehiculo_id`);

--
-- Indices de la tabla `soatanexo1`
--
ALTER TABLE `soatanexo1`
  ADD PRIMARY KEY (`id_vehiculosoat`),
  ADD UNIQUE KEY `soatanexo1__idx` (`vehiculoanexo1_vehiculoanexo1_id`);

--
-- Indices de la tabla `superficierodadura`
--
ALTER TABLE `superficierodadura`
  ADD PRIMARY KEY (`id_superficierodadura`),
  ADD UNIQUE KEY `superficierodadura__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `superficierodadura__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `suspsicoactivas`
--
ALTER TABLE `suspsicoactivas`
  ADD UNIQUE KEY `suspsicoactivas__idx` (`conductor_id_conductor`);

--
-- Indices de la tabla `suspsicoactivasanexo1`
--
ALTER TABLE `suspsicoactivasanexo1`
  ADD UNIQUE KEY `suspsicoactivasanexo1__idx` (`conductoranexo1_id_conductor`);

--
-- Indices de la tabla `utilizacion`
--
ALTER TABLE `utilizacion`
  ADD PRIMARY KEY (`id_ustilizacion`),
  ADD UNIQUE KEY `utilizacion__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `utilizacion__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD PRIMARY KEY (`vehiculo_id`),
  ADD UNIQUE KEY `vehiculo__idx` (`cvp_id_cvp`);

--
-- Indices de la tabla `vehiculoanexo1`
--
ALTER TABLE `vehiculoanexo1`
  ADD PRIMARY KEY (`vehiculoanexo1_id`),
  ADD UNIQUE KEY `vehiculoanexo1__idx` (`cvpanexo1_id_cvp`);

--
-- Indices de la tabla `vehiculopropietario`
--
ALTER TABLE `vehiculopropietario`
  ADD PRIMARY KEY (`id_propietarioclasevehiculo`),
  ADD UNIQUE KEY `vehiculopropietario__idx` (`propietario_id_propietario`);

--
-- Indices de la tabla `via1`
--
ALTER TABLE `via1`
  ADD PRIMARY KEY (`id_caracvia1`),
  ADD UNIQUE KEY `via1__idx` (`caracteristicasvia_id_caracvia`);

--
-- Indices de la tabla `via1croquis`
--
ALTER TABLE `via1croquis`
  ADD PRIMARY KEY (`id_via1`),
  ADD UNIQUE KEY `via1croquis__idx` (`croquis_id_croquis`);

--
-- Indices de la tabla `via2`
--
ALTER TABLE `via2`
  ADD PRIMARY KEY (`id_caracvia2`),
  ADD UNIQUE KEY `via2__idx` (`caracteristicasvia_id_caracvia`);

--
-- Indices de la tabla `via2croquis`
--
ALTER TABLE `via2croquis`
  ADD PRIMARY KEY (`id_via2`),
  ADD UNIQUE KEY `via2croquis__idx` (`croquis_id_croquis`);

--
-- Indices de la tabla `victimas`
--
ALTER TABLE `victimas`
  ADD PRIMARY KEY (`id_victimasanexo2`),
  ADD KEY `victimas_anexo2_fk` (`anexo2_id_anexo2`);

--
-- Indices de la tabla `visibilidad`
--
ALTER TABLE `visibilidad`
  ADD PRIMARY KEY (`id_visibilidad`),
  ADD UNIQUE KEY `visibilidad__idx` (`via1_id_caracvia1`),
  ADD UNIQUE KEY `visibilidad__idxv1` (`via2_id_caracvia2`);

--
-- Indices de la tabla `zona`
--
ALTER TABLE `zona`
  ADD PRIMARY KEY (`id_zona`),
  ADD UNIQUE KEY `zona__idx` (`caracteristicaslugar_id_caraclugar`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `agentetransito`
--
ALTER TABLE `agentetransito`
  ADD CONSTRAINT `agentetransito_controlestransito_fk` FOREIGN KEY (`controlestransito_id_controlestransito`) REFERENCES `controlestransito` (`id_controlestransito`);

--
-- Filtros para la tabla `anexo1`
--
ALTER TABLE `anexo1`
  ADD CONSTRAINT `anexo1_itboy_fk` FOREIGN KEY (`itboy_itboy_id`) REFERENCES `itboy` (`itboy_id`);

--
-- Filtros para la tabla `anexo2`
--
ALTER TABLE `anexo2`
  ADD CONSTRAINT `anexo2_itboy_fk` FOREIGN KEY (`itboy_itboy_id`) REFERENCES `itboy` (`itboy_id`);

--
-- Filtros para la tabla `area`
--
ALTER TABLE `area`
  ADD CONSTRAINT `area_caracteristicaslugar_fk` FOREIGN KEY (`caracteristicaslugar_id_caraclugar`) REFERENCES `caracteristicaslugar` (`id_caraclugar`);

--
-- Filtros para la tabla `calzadas`
--
ALTER TABLE `calzadas`
  ADD CONSTRAINT `calzadas_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `calzadas_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `caracteristicaslugar`
--
ALTER TABLE `caracteristicaslugar`
  ADD CONSTRAINT `caracteristicaslugar_informepolicial_fk` FOREIGN KEY (`informepolicial_id_informe`) REFERENCES `informepolicial` (`id_informe`);

--
-- Filtros para la tabla `caracteristicasvia`
--
ALTER TABLE `caracteristicasvia`
  ADD CONSTRAINT `caracteristicasvia_informepolicial_fk` FOREIGN KEY (`informepolicial_id_informe`) REFERENCES `informepolicial` (`id_informe`);

--
-- Filtros para la tabla `carga`
--
ALTER TABLE `carga`
  ADD CONSTRAINT `carga_modalidadtrans_fk` FOREIGN KEY (`modalidadtrans_id_modtrans`) REFERENCES `modalidadtrans` (`id_modtrans`);

--
-- Filtros para la tabla `carriles`
--
ALTER TABLE `carriles`
  ADD CONSTRAINT `carriles_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `carriles_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `choqueobjeto`
--
ALTER TABLE `choqueobjeto`
  ADD CONSTRAINT `choqueobjeto_claseaccidente_fk` FOREIGN KEY (`claseaccidente_id_claseaccidente`,`claseaccidente_id_informe`) REFERENCES `claseaccidente` (`id_claseaccidente`, `informepolicial_id_informe`);

--
-- Filtros para la tabla `choqueobjetofijo`
--
ALTER TABLE `choqueobjetofijo`
  ADD CONSTRAINT `choqueobjetofijo_claseaccidente_fk` FOREIGN KEY (`claseaccidente_id_claseaccidente`,`claseaccidente_id_informe`) REFERENCES `claseaccidente` (`id_claseaccidente`, `informepolicial_id_informe`);

--
-- Filtros para la tabla `claseaccidente`
--
ALTER TABLE `claseaccidente`
  ADD CONSTRAINT `claseaccidente_informepolicial_fk` FOREIGN KEY (`informepolicial_id_informe`) REFERENCES `informepolicial` (`id_informe`);

--
-- Filtros para la tabla `claseservicio`
--
ALTER TABLE `claseservicio`
  ADD CONSTRAINT `claseservicio_vehiculopropietario_fk` FOREIGN KEY (`vehiculopropietario_id_propietarioclasevehiculo`) REFERENCES `vehiculopropietario` (`id_propietarioclasevehiculo`);

--
-- Filtros para la tabla `condicion`
--
ALTER TABLE `condicion`
  ADD CONSTRAINT `condicion_detallesvictima_fk` FOREIGN KEY (`detallesvictima_id_victimadetalles`) REFERENCES `detallesvictima` (`id_victimadetalles`);

--
-- Filtros para la tabla `condicionclimatica`
--
ALTER TABLE `condicionclimatica`
  ADD CONSTRAINT `condicionclimatica_caracteristicaslugar_fk` FOREIGN KEY (`caracteristicaslugar_id_caraclugar`) REFERENCES `caracteristicaslugar` (`id_caraclugar`);

--
-- Filtros para la tabla `condiciones`
--
ALTER TABLE `condiciones`
  ADD CONSTRAINT `condiciones_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `condiciones_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `conductor`
--
ALTER TABLE `conductor`
  ADD CONSTRAINT `conductor_conductoresvehiculospropietarios_fk` FOREIGN KEY (`cvp_id_cvp`) REFERENCES `conductoresvehiculospropietarios` (`id_conductoresvehiculospropietarios`);

--
-- Filtros para la tabla `conductoranexo1`
--
ALTER TABLE `conductoranexo1`
  ADD CONSTRAINT `conductoranexo1_conductoresvehiculospropietariosanexo1_fk` FOREIGN KEY (`cvpanexo1_id_cvp`) REFERENCES `conductoresvehiculospropietariosanexo1` (`id_conductoresvehiculospropietarios`);

--
-- Filtros para la tabla `conductoresvehiculospropietarios`
--
ALTER TABLE `conductoresvehiculospropietarios`
  ADD CONSTRAINT `conductoresvehiculospropietarios_informepolicial_fk` FOREIGN KEY (`informepolicial_id_informe`) REFERENCES `informepolicial` (`id_informe`);

--
-- Filtros para la tabla `conductoresvehiculospropietariosanexo1`
--
ALTER TABLE `conductoresvehiculospropietariosanexo1`
  ADD CONSTRAINT `conductoresvehiculospropietariosanexo1_anexo1_fk` FOREIGN KEY (`anexo1_id_anexo1`) REFERENCES `anexo1` (`id_anexo1`);

--
-- Filtros para la tabla `controlestransito`
--
ALTER TABLE `controlestransito`
  ADD CONSTRAINT `controlestransito_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `controlestransito_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `correspondio`
--
ALTER TABLE `correspondio`
  ADD CONSTRAINT `correspondio_anexo1_fk` FOREIGN KEY (`anexo1_id_anexo1`) REFERENCES `anexo1` (`id_anexo1`);

--
-- Filtros para la tabla `correspondioanexo2`
--
ALTER TABLE `correspondioanexo2`
  ADD CONSTRAINT `correspondioanexo2_anexo2_fk` FOREIGN KEY (`anexo2_id_anexo2`) REFERENCES `anexo2` (`id_anexo2`);

--
-- Filtros para la tabla `correspondiocroquis`
--
ALTER TABLE `correspondiocroquis`
  ADD CONSTRAINT `correspondiocroquis_croquis_fk` FOREIGN KEY (`croquis_id_croquis`) REFERENCES `croquis` (`id_croquis`);

--
-- Filtros para la tabla `croquis`
--
ALTER TABLE `croquis`
  ADD CONSTRAINT `croquis_itboy_fk` FOREIGN KEY (`itboy_itboy_id`) REFERENCES `itboy` (`itboy_id`);

--
-- Filtros para la tabla `datosquienconoceaccidente`
--
ALTER TABLE `datosquienconoceaccidente`
  ADD CONSTRAINT `datosquienconoceaccidente_anexo1_fk` FOREIGN KEY (`anexo1_id_anexo1`) REFERENCES `anexo1` (`id_anexo1`);

--
-- Filtros para la tabla `datosquienconoceaccidenteanexo2`
--
ALTER TABLE `datosquienconoceaccidenteanexo2`
  ADD CONSTRAINT `datosquienconoceaccidenteanexo2_anexo2_fk` FOREIGN KEY (`anexo2_id_anexo2`) REFERENCES `anexo2` (`id_anexo2`);

--
-- Filtros para la tabla `datosquienconoceaccidentecroquis`
--
ALTER TABLE `datosquienconoceaccidentecroquis`
  ADD CONSTRAINT `datosquienconoceaccidentecroquis_croquis_fk` FOREIGN KEY (`croquis_id_croquis`) REFERENCES `croquis` (`id_croquis`);

--
-- Filtros para la tabla `delineadorpiso`
--
ALTER TABLE `delineadorpiso`
  ADD CONSTRAINT `delineadorpiso_controlestransito_fk` FOREIGN KEY (`controlestransito_id_controlestransito`) REFERENCES `controlestransito` (`id_controlestransito`);

--
-- Filtros para la tabla `detallesvictima`
--
ALTER TABLE `detallesvictima`
  ADD CONSTRAINT `detallesvictima_victimas_fk` FOREIGN KEY (`victimas_id_victimasanexo2`) REFERENCES `victimas` (`id_victimasanexo2`);

--
-- Filtros para la tabla `diseno`
--
ALTER TABLE `diseno`
  ADD CONSTRAINT `diseno_caracteristicaslugar_fk` FOREIGN KEY (`caracteristicaslugar_id_caraclugar`) REFERENCES `caracteristicaslugar` (`id_caraclugar`);

--
-- Filtros para la tabla `embriaguez`
--
ALTER TABLE `embriaguez`
  ADD CONSTRAINT `embriaguez_conductor_fk` FOREIGN KEY (`conductor_id_conductor`) REFERENCES `conductor` (`id_conductor`);

--
-- Filtros para la tabla `embriaguezanexo1`
--
ALTER TABLE `embriaguezanexo1`
  ADD CONSTRAINT `embriaguezanexo1_conductoranexo1_fk` FOREIGN KEY (`conductoranexo1_id_conductor`) REFERENCES `conductoranexo1` (`id_conductor`);

--
-- Filtros para la tabla `embriaguezvictima`
--
ALTER TABLE `embriaguezvictima`
  ADD CONSTRAINT `embriaguezvictima_detallesvictima_fk` FOREIGN KEY (`detallesvictima_id_victimadetalles`) REFERENCES `detallesvictima` (`id_victimadetalles`);

--
-- Filtros para la tabla `estado`
--
ALTER TABLE `estado`
  ADD CONSTRAINT `estado_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `estado_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `examen`
--
ALTER TABLE `examen`
  ADD CONSTRAINT `examen_conductor_fk` FOREIGN KEY (`conductor_id_conductor`) REFERENCES `conductor` (`id_conductor`);

--
-- Filtros para la tabla `examenanexo1`
--
ALTER TABLE `examenanexo1`
  ADD CONSTRAINT `examenanexo1_conductoranexo1_fk` FOREIGN KEY (`conductoranexo1_id_conductor`) REFERENCES `conductoranexo1` (`id_conductor`);

--
-- Filtros para la tabla `fallas`
--
ALTER TABLE `fallas`
  ADD CONSTRAINT `fallas_informepolicial_fk` FOREIGN KEY (`informepolicial_id_informe`) REFERENCES `informepolicial` (`id_informe`);

--
-- Filtros para la tabla `geometricas`
--
ALTER TABLE `geometricas`
  ADD CONSTRAINT `geometricas_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `geometricas_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `gravedad`
--
ALTER TABLE `gravedad`
  ADD CONSTRAINT `gravedad_detallesvictima_fk` FOREIGN KEY (`detallesvictima_id_victimadetalles`) REFERENCES `detallesvictima` (`id_victimadetalles`);

--
-- Filtros para la tabla `hipotesisiaccidente`
--
ALTER TABLE `hipotesisiaccidente`
  ADD CONSTRAINT `hipotesisiaccidente_anexo1_fk` FOREIGN KEY (`anexo1_id_anexo1`) REFERENCES `anexo1` (`id_anexo1`);

--
-- Filtros para la tabla `iluminacionartificial`
--
ALTER TABLE `iluminacionartificial`
  ADD CONSTRAINT `iluminacionartificial_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `iluminacionartificial_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `informepolicial`
--
ALTER TABLE `informepolicial`
  ADD CONSTRAINT `informepolicial_itboy_fk` FOREIGN KEY (`itboy_itboy_id`) REFERENCES `itboy` (`itboy_id`);

--
-- Filtros para la tabla `licencia`
--
ALTER TABLE `licencia`
  ADD CONSTRAINT `licencia_conductor_fk` FOREIGN KEY (`conductor_id_conductor`) REFERENCES `conductor` (`id_conductor`);

--
-- Filtros para la tabla `licenciaanexo1`
--
ALTER TABLE `licenciaanexo1`
  ADD CONSTRAINT `licenciaanexo1_conductoranexo1_fk` FOREIGN KEY (`conductoranexo1_id_conductor`) REFERENCES `conductoranexo1` (`id_conductor`);

--
-- Filtros para la tabla `longhuellas`
--
ALTER TABLE `longhuellas`
  ADD CONSTRAINT `longhuellas_croquis_fk` FOREIGN KEY (`croquis_id_croquis`) REFERENCES `croquis` (`id_croquis`);

--
-- Filtros para la tabla `lugarimpacto`
--
ALTER TABLE `lugarimpacto`
  ADD CONSTRAINT `lugarimpacto_fallas_fk` FOREIGN KEY (`fallas_id_fallasvehiculo`) REFERENCES `fallas` (`id_fallasvehiculo`);

--
-- Filtros para la tabla `mismoconductor`
--
ALTER TABLE `mismoconductor`
  ADD CONSTRAINT `mismoconductor_propietario_fk` FOREIGN KEY (`propietario_id_propietario`) REFERENCES `propietario` (`id_propietario`);

--
-- Filtros para la tabla `mixto`
--
ALTER TABLE `mixto`
  ADD CONSTRAINT `mixto_modalidadtrans_fk` FOREIGN KEY (`modalidadtrans_id_modtrans`) REFERENCES `modalidadtrans` (`id_modtrans`);

--
-- Filtros para la tabla `modalidadtrans`
--
ALTER TABLE `modalidadtrans`
  ADD CONSTRAINT `modalidadtrans_vehiculopropietario_fk` FOREIGN KEY (`vehiculopropietario_id_propietarioclasevehiculo`) REFERENCES `vehiculopropietario` (`id_propietarioclasevehiculo`);

--
-- Filtros para la tabla `nacionalidad`
--
ALTER TABLE `nacionalidad`
  ADD CONSTRAINT `nacionalidad_vehiculo_fk` FOREIGN KEY (`vehiculo_vehiculo_id`) REFERENCES `vehiculo` (`vehiculo_id`);

--
-- Filtros para la tabla `nacionalidadanexo1`
--
ALTER TABLE `nacionalidadanexo1`
  ADD CONSTRAINT `nacionalidadanexo1_vehiculoanexo1_fk` FOREIGN KEY (`vehiculoanexo1_vehiculoanexo1_id`) REFERENCES `vehiculoanexo1` (`vehiculoanexo1_id`);

--
-- Filtros para la tabla `observaciones`
--
ALTER TABLE `observaciones`
  ADD CONSTRAINT `observaciones_anexo2_fk` FOREIGN KEY (`anexo2_id_anexo2`) REFERENCES `anexo2` (`id_anexo2`);

--
-- Filtros para la tabla `pasajeros`
--
ALTER TABLE `pasajeros`
  ADD CONSTRAINT `pasajeros_modalidadtrans_fk` FOREIGN KEY (`modalidadtrans_id_modtrans`) REFERENCES `modalidadtrans` (`id_modtrans`);

--
-- Filtros para la tabla `poliza`
--
ALTER TABLE `poliza`
  ADD CONSTRAINT `poliza_vehiculo_fk` FOREIGN KEY (`vehiculo_vehiculo_id`) REFERENCES `vehiculo` (`vehiculo_id`);

--
-- Filtros para la tabla `polizaanexo1`
--
ALTER TABLE `polizaanexo1`
  ADD CONSTRAINT `polizaanexo1_vehiculoanexo1_fk` FOREIGN KEY (`vehiculoanexo1_vehiculoanexo1_id`) REFERENCES `vehiculoanexo1` (`vehiculoanexo1_id`);

--
-- Filtros para la tabla `propietario`
--
ALTER TABLE `propietario`
  ADD CONSTRAINT `propietario_informepolicial_fk` FOREIGN KEY (`informepolicial_id_informe`) REFERENCES `informepolicial` (`id_informe`);

--
-- Filtros para la tabla `radioaccion`
--
ALTER TABLE `radioaccion`
  ADD CONSTRAINT `radioaccion_vehiculopropietario_fk` FOREIGN KEY (`vehiculopropietario_id_propietarioclasevehiculo`) REFERENCES `vehiculopropietario` (`id_propietarioclasevehiculo`);

--
-- Filtros para la tabla `reductorvelocidad`
--
ALTER TABLE `reductorvelocidad`
  ADD CONSTRAINT `reductorvelocidad_controlestransito_fk` FOREIGN KEY (`controlestransito_id_controlestransito`) REFERENCES `controlestransito` (`id_controlestransito`);

--
-- Filtros para la tabla `responsabilidadcivilcontractual`
--
ALTER TABLE `responsabilidadcivilcontractual`
  ADD CONSTRAINT `responsabilidadcivilcontractual_vehiculo_fk` FOREIGN KEY (`vehiculo_vehiculo_id`) REFERENCES `vehiculo` (`vehiculo_id`);

--
-- Filtros para la tabla `responsabilidadcivilcontractualanexo1`
--
ALTER TABLE `responsabilidadcivilcontractualanexo1`
  ADD CONSTRAINT `responsabilidadcivilcontractualanexo1_vehiculoanexo1_fk` FOREIGN KEY (`vehiculoanexo1_vehiculoanexo1_id`) REFERENCES `vehiculoanexo1` (`vehiculoanexo1_id`);

--
-- Filtros para la tabla `responsabilidadextracondicional`
--
ALTER TABLE `responsabilidadextracondicional`
  ADD CONSTRAINT `responsabilidadextracondicional_vehiculo_fk` FOREIGN KEY (`vehiculo_vehiculo_id`) REFERENCES `vehiculo` (`vehiculo_id`);

--
-- Filtros para la tabla `responsabilidadextracondicionalanexo1`
--
ALTER TABLE `responsabilidadextracondicionalanexo1`
  ADD CONSTRAINT `responsabilidadextracondicionalanexo1_vehiculoanexo1_fk` FOREIGN KEY (`vehiculoanexo1_vehiculoanexo1_id`) REFERENCES `vehiculoanexo1` (`vehiculoanexo1_id`);

--
-- Filtros para la tabla `revtecmec`
--
ALTER TABLE `revtecmec`
  ADD CONSTRAINT `revtecmec_vehiculo_fk` FOREIGN KEY (`vehiculo_vehiculo_id`) REFERENCES `vehiculo` (`vehiculo_id`);

--
-- Filtros para la tabla `revtecmecanexo1`
--
ALTER TABLE `revtecmecanexo1`
  ADD CONSTRAINT `revtecmecanexo1_vehiculoanexo1_fk` FOREIGN KEY (`vehiculoanexo1_vehiculoanexo1_id`) REFERENCES `vehiculoanexo1` (`vehiculoanexo1_id`);

--
-- Filtros para la tabla `sector`
--
ALTER TABLE `sector`
  ADD CONSTRAINT `sector_caracteristicaslugar_fk` FOREIGN KEY (`caracteristicaslugar_id_caraclugar`) REFERENCES `caracteristicaslugar` (`id_caraclugar`);

--
-- Filtros para la tabla `semaforo`
--
ALTER TABLE `semaforo`
  ADD CONSTRAINT `semaforo_controlestransito_fk` FOREIGN KEY (`controlestransito_id_controlestransito`) REFERENCES `controlestransito` (`id_controlestransito`);

--
-- Filtros para la tabla `senaleshorizontales`
--
ALTER TABLE `senaleshorizontales`
  ADD CONSTRAINT `senaleshorizontales_controlestransito_fk` FOREIGN KEY (`controlestransito_id_controlestransito`) REFERENCES `controlestransito` (`id_controlestransito`);

--
-- Filtros para la tabla `senalesverticales`
--
ALTER TABLE `senalesverticales`
  ADD CONSTRAINT `senalesverticales_controlestransito_fk` FOREIGN KEY (`controlestransito_id_controlestransito`) REFERENCES `controlestransito` (`id_controlestransito`);

--
-- Filtros para la tabla `soat`
--
ALTER TABLE `soat`
  ADD CONSTRAINT `soat_vehiculo_fk` FOREIGN KEY (`vehiculo_vehiculo_id`) REFERENCES `vehiculo` (`vehiculo_id`);

--
-- Filtros para la tabla `soatanexo1`
--
ALTER TABLE `soatanexo1`
  ADD CONSTRAINT `soatanexo1_vehiculoanexo1_fk` FOREIGN KEY (`vehiculoanexo1_vehiculoanexo1_id`) REFERENCES `vehiculoanexo1` (`vehiculoanexo1_id`);

--
-- Filtros para la tabla `superficierodadura`
--
ALTER TABLE `superficierodadura`
  ADD CONSTRAINT `superficierodadura_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `superficierodadura_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `suspsicoactivas`
--
ALTER TABLE `suspsicoactivas`
  ADD CONSTRAINT `suspsicoactivas_conductor_fk` FOREIGN KEY (`conductor_id_conductor`) REFERENCES `conductor` (`id_conductor`);

--
-- Filtros para la tabla `suspsicoactivasanexo1`
--
ALTER TABLE `suspsicoactivasanexo1`
  ADD CONSTRAINT `suspsicoactivasanexo1_conductoranexo1_fk` FOREIGN KEY (`conductoranexo1_id_conductor`) REFERENCES `conductoranexo1` (`id_conductor`);

--
-- Filtros para la tabla `utilizacion`
--
ALTER TABLE `utilizacion`
  ADD CONSTRAINT `utilizacion_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `utilizacion_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD CONSTRAINT `vehiculo_conductoresvehiculospropietarios_fk` FOREIGN KEY (`cvp_id_cvp`) REFERENCES `conductoresvehiculospropietarios` (`id_conductoresvehiculospropietarios`);

--
-- Filtros para la tabla `vehiculoanexo1`
--
ALTER TABLE `vehiculoanexo1`
  ADD CONSTRAINT `vehiculoanexo1_conductoresvehiculospropietariosanexo1_fk` FOREIGN KEY (`cvpanexo1_id_cvp`) REFERENCES `conductoresvehiculospropietariosanexo1` (`id_conductoresvehiculospropietarios`);

--
-- Filtros para la tabla `vehiculopropietario`
--
ALTER TABLE `vehiculopropietario`
  ADD CONSTRAINT `vehiculopropietario_propietario_fk` FOREIGN KEY (`propietario_id_propietario`) REFERENCES `propietario` (`id_propietario`);

--
-- Filtros para la tabla `via1`
--
ALTER TABLE `via1`
  ADD CONSTRAINT `via1_caracteristicasvia_fk` FOREIGN KEY (`caracteristicasvia_id_caracvia`) REFERENCES `caracteristicasvia` (`id_caracvia`);

--
-- Filtros para la tabla `via1croquis`
--
ALTER TABLE `via1croquis`
  ADD CONSTRAINT `via1croquis_croquis_fk` FOREIGN KEY (`croquis_id_croquis`) REFERENCES `croquis` (`id_croquis`);

--
-- Filtros para la tabla `via2`
--
ALTER TABLE `via2`
  ADD CONSTRAINT `via2_caracteristicasvia_fk` FOREIGN KEY (`caracteristicasvia_id_caracvia`) REFERENCES `caracteristicasvia` (`id_caracvia`);

--
-- Filtros para la tabla `via2croquis`
--
ALTER TABLE `via2croquis`
  ADD CONSTRAINT `via2croquis_croquis_fk` FOREIGN KEY (`croquis_id_croquis`) REFERENCES `croquis` (`id_croquis`);

--
-- Filtros para la tabla `victimas`
--
ALTER TABLE `victimas`
  ADD CONSTRAINT `victimas_anexo2_fk` FOREIGN KEY (`anexo2_id_anexo2`) REFERENCES `anexo2` (`id_anexo2`);

--
-- Filtros para la tabla `visibilidad`
--
ALTER TABLE `visibilidad`
  ADD CONSTRAINT `visibilidad_via1_fk` FOREIGN KEY (`via1_id_caracvia1`) REFERENCES `via1` (`id_caracvia1`),
  ADD CONSTRAINT `visibilidad_via2_fk` FOREIGN KEY (`via2_id_caracvia2`) REFERENCES `via2` (`id_caracvia2`);

--
-- Filtros para la tabla `zona`
--
ALTER TABLE `zona`
  ADD CONSTRAINT `zona_caracteristicaslugar_fk` FOREIGN KEY (`caracteristicaslugar_id_caraclugar`) REFERENCES `caracteristicaslugar` (`id_caraclugar`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
