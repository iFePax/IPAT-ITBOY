<?php
    $server = "localhost";
    $user = "root";
    $password = "";
    $database = "itap_itboy";

    $db = mysqli_connect($server,$user,$password,$database);
    mysqli_query($db,"SET NAMES 'utf8'");

    if(mysqli_connect_errno()){
        echo "Fallo la conexion a la base de datos".mysqli_connect_error();
    }
    
?>